create extension if not exists pgcrypto;

create table if not exists public.secret_messages (
  id uuid primary key default gen_random_uuid(),
  ciphertext text not null,
  expires_at timestamptz null,
  created_at timestamptz not null default now()
);

alter table public.secret_messages enable row level security;

drop policy if exists "public insert secret messages" on public.secret_messages;
drop policy if exists "read unexpired secret messages" on public.secret_messages;

create policy "public insert secret messages"
on public.secret_messages
for insert to anon
with check (
  length(ciphertext) > 0
  and (expires_at is null or expires_at > now())
);

create policy "read unexpired secret messages"
on public.secret_messages
for select to anon
using (
  expires_at is null or expires_at > now()
);
